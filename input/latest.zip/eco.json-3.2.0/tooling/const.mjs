const ecoCats = ["A", "B", "C", "D", "E"]

export {ecoCats}